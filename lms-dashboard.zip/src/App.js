import React from 'react';

export default function App() {
  return (
    <div style={{padding:'20px',fontFamily:'Arial'}}>
      <h1>Learning Management System Dashboard</h1>
      <div style={{display:'flex',gap:'20px'}}>
        <div><h3>Students</h3><p>250</p></div>
        <div><h3>Courses</h3><p>15</p></div>
        <div><h3>Assignments</h3><p>32</p></div>
      </div>
    </div>
  );
}
